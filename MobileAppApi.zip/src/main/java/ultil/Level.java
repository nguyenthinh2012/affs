package ultil;

public class Level {
    int id;
    String name;
    String description;
    int status;
}
