package ultil;

public class StatusCall {
    int id;
    String name;
    String description;
    int call_active;
    int status;
}
