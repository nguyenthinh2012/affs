package ultil;

public class NumCtsLevel {
    int num;
    int current_level;
}
