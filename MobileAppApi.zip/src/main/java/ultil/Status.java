package ultil;

public class Status {
    int status;

    public Status(int i){
        this.status = i;
    }
    public void setStatus(int status) {
        this.status = status;
    }
}
